# Build APK LeoPrediksi hanya dari HP

1. Buat akun GitHub dan login di https://github.com.
2. Buat repository baru bernama `LeoPrediksi-Android` (Private disarankan).
3. Upload seluruh isi folder project ini ke repository, bukan folder induknya.
4. Buka tab Actions pada repository. Jika diminta, aktifkan Actions.
5. Pilih workflow `Build LeoPrediksi APK`, tekan `Run workflow`.
6. Tunggu sampai workflow hijau. Buka hasil run, bagian Artifacts, unduh `LeoPrediksi-debug-apk`.
7. Ekstrak ZIP artifact, lalu instal `app-debug.apk` di Android. Izinkan instalasi dari sumber ini bila Android meminta.

Catatan: APK debug untuk uji coba, belum untuk distribusi publik. Source saat ini masih starter dan memerlukan perbaikan/pengujian integrasi backend sebelum pembayaran/member sungguhan. Jangan masukkan kredensial rahasia. `google-services.json` berisi konfigurasi aplikasi Firebase, bukan password, tetapi repository Private tetap disarankan.
