const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
initializeApp();
const db = getFirestore();

async function requireUser(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Silakan login.");
  return request.auth.uid;
}
async function requireAdmin(uid) {
  const snap = await db.doc(`users/${uid}`).get();
  if (!snap.exists || snap.data().role !== "admin") throw new HttpsError("permission-denied", "Khusus admin.");
}

exports.createPrediction = onCall(async (request) => {
  const uid = await requireUser(request); await requireAdmin(uid);
  const { category, home, away, selection } = request.data || {};
  const allowed = ["Gratis", "Premium", "Premium HDC", "Premium Over Under"];
  if (!allowed.includes(category) || !home || !away || !selection)
    throw new HttpsError("invalid-argument", "Data prediksi belum lengkap.");
  const ref = await db.collection("predictions").add({
    category, home, away, selection, status: "PENDING", score: "-",
    createdAt: FieldValue.serverTimestamp(), createdBy: uid
  });
  return { id: ref.id };
});

exports.settlePrediction = onCall(async (request) => {
  const uid = await requireUser(request); await requireAdmin(uid);
  const { predictionId, status, score } = request.data || {};
  if (!predictionId || !["WIN", "LOSE"].includes(status) || !score)
    throw new HttpsError("invalid-argument", "Hasil dan skor harus diisi.");
  await db.doc(`predictions/${predictionId}`).update({
    status, score, settledAt: FieldValue.serverTimestamp(), settledBy: uid
  });
  return { ok: true };
});

exports.unlockPrediction = onCall(async (request) => {
  const uid = await requireUser(request);
  const { predictionId } = request.data || {};
  if (!predictionId) throw new HttpsError("invalid-argument", "ID prediksi wajib diisi.");
  const userRef = db.doc(`users/${uid}`);
  const predRef = db.doc(`predictions/${predictionId}`);
  return db.runTransaction(async (tx) => {
    const [u, p] = await Promise.all([tx.get(userRef), tx.get(predRef)]);
    if (!u.exists || !p.exists) throw new HttpsError("not-found", "Data tidak ditemukan.");
    const category = p.data().category;
    if (category === "Gratis") return { selection: p.data().selection };
    const vipUntil = u.data().vipUntil || 0;
    if (vipUntil > Date.now()) return { selection: p.data().selection, vip: true };
    const receiptId = `${uid}_${predictionId}`;
    const receiptRef = db.doc(`unlockReceipts/${receiptId}`);
    const receipt = await tx.get(receiptRef);
    if (receipt.exists) return { selection: p.data().selection, alreadyUnlocked: true };
    const coins = u.data().coins || 0;
    if (coins < 3) throw new HttpsError("failed-precondition", "Koin tidak cukup.");
    tx.update(userRef, { coins: coins - 3 });
    tx.create(receiptRef, { uid, predictionId, cost: 3, createdAt: FieldValue.serverTimestamp() });
    return { selection: p.data().selection };
  });
});

// Admin-only manual grant. Call from a trusted admin tool after payment verification.
exports.grantMemberEntitlement = onCall(async (request) => {
  const uid = await requireUser(request); await requireAdmin(uid);
  const { memberUid, coins = 0, vipDays = 0 } = request.data || {};
  if (!memberUid || !Number.isInteger(coins) || coins < 0 || !Number.isInteger(vipDays) || vipDays < 0)
    throw new HttpsError("invalid-argument", "Data pemberian tidak valid.");
  const ref = db.doc(`users/${memberUid}`);
  await db.runTransaction(async tx => {
    const snap = await tx.get(ref);
    if (!snap.exists) throw new HttpsError("not-found", "Member tidak ditemukan.");
    const oldUntil = snap.data().vipUntil || 0;
    const base = Math.max(Date.now(), oldUntil);
    tx.update(ref, {
      coins: (snap.data().coins || 0) + coins,
      vipUntil: vipDays ? base + vipDays * 86400000 : oldUntil
    });
  });
  return { ok: true };
});
