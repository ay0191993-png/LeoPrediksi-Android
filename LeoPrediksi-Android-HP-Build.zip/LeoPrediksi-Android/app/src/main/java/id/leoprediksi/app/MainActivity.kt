package id.leoprediksi.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private val auth by lazy { FirebaseAuth.getInstance() }
private val db by lazy { FirebaseFirestore.getInstance() }
private const val WA = "6285129371159"

data class Pick(val id: String, val category: String, val home: String, val away: String,
                val selection: String, val status: String, val score: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LeoApp() }
    }
}

@Composable
fun LeoApp() {
    var user by remember { mutableStateOf(auth.currentUser) }
    var role by remember { mutableStateOf("member") }
    var coins by remember { mutableIntStateOf(0) }
    var vipUntil by remember { mutableStateOf<Long?>(null) }
    var picks by remember { mutableStateOf(listOf<Pick>()) }
    var page by remember { mutableStateOf("auth") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    suspend fun refresh() {
        val u = auth.currentUser ?: return
        val doc = db.collection("users").document(u.uid).get().await()
        role = doc.getString("role") ?: "member"
        coins = (doc.getLong("coins") ?: 0L).toInt()
        vipUntil = doc.getLong("vipUntil")
        val snap = db.collection("predictions").orderBy("createdAt").get().await()
        picks = snap.documents.map {
            Pick(it.id, it.getString("category") ?: "Gratis",
                it.getString("home") ?: "", it.getString("away") ?: "",
                it.getString("selection") ?: "", it.getString("status") ?: "PENDING",
                it.getString("score") ?: "-")
        }
        page = "home"
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFFE5B94B))) {
        Surface(Modifier.fillMaxSize()) {
            if (user == null) {
                AuthScreen(email, { email = it }, password, { password = it }, error,
                    onLogin = {
                        scope.launch {
                            try { auth.signInWithEmailAndPassword(email.trim(), password).await(); user = auth.currentUser; refresh() }
                            catch (e: Exception) { error = e.localizedMessage ?: "Login gagal" }
                        }
                    },
                    onRegister = {
                        scope.launch {
                            try {
                                val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
                                val uid = result.user?.uid ?: error("Akun tidak ditemukan")
                                db.collection("users").document(uid).set(mapOf("email" to email.trim(), "role" to "member", "coins" to 0, "vipUntil" to 0L)).await()
                                user = auth.currentUser; refresh()
                            } catch (e: Exception) { error = e.localizedMessage ?: "Pendaftaran gagal" }
                        }
                    })
            } else if (page == "home") {
                HomeScreen(role, coins, vipUntil, picks,
                    onAdmin = { page = "admin" },
                    onLogout = { auth.signOut(); user = null; page = "auth" },
                    onRefresh = { scope.launch { try { refresh() } catch (e: Exception) { error = e.localizedMessage ?: "Gagal memuat data" } } },
                    onBuy = { msg -> openWhatsApp(msg) },
                    onUnlock = { pick ->
                        scope.launch {
                            try {
                                val result = com.google.firebase.functions.FirebaseFunctions.getInstance()
                                    .getHttpsCallable("unlockPrediction").call(mapOf("predictionId" to pick.id)).await()
                                error = "Prediksi berhasil dibuka. Muat ulang untuk melihat detail."
                                refresh()
                            } catch (e: Exception) { error = e.localizedMessage ?: "Gagal membuka prediksi" }
                        }
                    }, message = error)
            } else {
                AdminScreen(
                    onBack = { page = "home" },
                    onCreate = { cat, home, away, selection ->
                        scope.launch {
                            try {
                                com.google.firebase.functions.FirebaseFunctions.getInstance()
                                    .getHttpsCallable("createPrediction")
                                    .call(mapOf("category" to cat, "home" to home, "away" to away, "selection" to selection)).await()
                                refresh()
                            } catch (e: Exception) { error = e.localizedMessage ?: "Tidak dapat menyimpan prediksi" }
                        }
                    },
                    onSettle = { id, result, score ->
                        scope.launch {
                            try {
                                com.google.firebase.functions.FirebaseFunctions.getInstance()
                                    .getHttpsCallable("settlePrediction")
                                    .call(mapOf("predictionId" to id, "status" to result, "score" to score)).await()
                                refresh()
                            } catch (e: Exception) { error = e.localizedMessage ?: "Koreksi gagal" }
                        }
                    },
                    onGrant = { memberUid, addCoins, vipDays ->
                        scope.launch {
                            try {
                                com.google.firebase.functions.FirebaseFunctions.getInstance()
                                    .getHttpsCallable("grantMemberEntitlement")
                                    .call(mapOf("memberUid" to memberUid, "coins" to addCoins, "vipDays" to vipDays)).await()
                                error = "Koin/VIP berhasil diberikan"
                            } catch (e: Exception) { error = e.localizedMessage ?: "Pemberian akses gagal" }
                        }
                    }, picks = picks, message = error)
            }
        }
    }
}

@Composable
private fun AuthScreen(email: String, setEmail: (String) -> Unit, password: String,
                       setPassword: (String) -> Unit, error: String,
                       onLogin: () -> Unit, onRegister: () -> Unit) {
    var register by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("LeoPrediksi", style = MaterialTheme.typography.headlineLarge)
        Text("FOOTBALL PREDICTION")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(email, setEmail, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, setPassword, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(onClick = { if (register) onRegister() else onLogin() }, modifier = Modifier.fillMaxWidth()) {
            Text(if (register) "DAFTAR" else "LOGIN")
        }
        TextButton(onClick = { register = !register }) { Text(if (register) "Sudah punya akun? Login" else "Belum punya akun? Daftar") }
        Text(error, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun HomeScreen(role: String, coins: Int, vipUntil: Long?, picks: List<Pick>,
                       onAdmin: () -> Unit, onLogout: () -> Unit, onRefresh: () -> Unit,
                       onBuy: (String) -> Unit, onUnlock: (Pick) -> Unit, message: String) {
    var category by remember { mutableStateOf("Gratis") }
    val categories = listOf("Gratis", "Premium", "Premium HDC", "Premium Over Under")
    val context = LocalContext.current
    fun contactAdmin(message: String) {
        val uri = Uri.parse("https://wa.me/$WA?text=${Uri.encode(message)}")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("LeoPrediksi", style = MaterialTheme.typography.headlineMedium)
            TextButton(onClick = onLogout) { Text("Keluar") }
        }
        Text("Saldo: $coins koin  •  VIP: ${if ((vipUntil ?: 0L) > System.currentTimeMillis()) "Aktif" else "Tidak aktif"}")
        Row {
            TextButton(onClick = { contactAdmin("Halo Admin, saya ingin membeli paket koin. Mohon info pembayaran.") }) { Text("Beli Koin") }
            TextButton(onClick = { contactAdmin("Halo Admin, saya ingin berlangganan VIP harian. Mohon info pembayaran.") }) { Text("VIP") }
        }
        Text("Paket koin: 10k=10, 15k=17, 20k=25, 30k=40")
        Text("VIP: 5k/3 hari, 10k/6 hari, 15k/11 hari, 20k/15 hari")
        Text("Buka prediksi premium: 3 koin")
        Row { TextButton(onClick = onRefresh) { Text("Muat ulang") }; if (role == "admin") TextButton(onClick = onAdmin) { Text("Room Admin") } }
        categories.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) }) }
        LazyColumn {
            items(picks.filter { it.category == category }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${p.home} vs ${p.away}", style = MaterialTheme.typography.titleMedium)
                        Text(if (p.category == "Gratis" || p.status != "PENDING") p.selection else "Pilihan terkunci")
                        Text("Status: ${p.status} • Skor: ${p.score}")
                        if (p.category != "Gratis" && p.status == "PENDING") Button(onClick = { onUnlock(p) }) { Text("BUKA • 3 KOIN") }
                    }
                }
            }
        }
        Text(message, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun AdminScreen(onBack: () -> Unit, onCreate: (String, String, String, String) -> Unit,
                        onSettle: (String, String, String) -> Unit,
                        onGrant: (String, Int, Int) -> Unit, picks: List<Pick>, message: String) {
    var memberUid by remember { mutableStateOf("") }
    var grantCoins by remember { mutableStateOf("10") }
    var grantVipDays by remember { mutableStateOf("0") }
    var category by remember { mutableStateOf("Gratis") }
    var home by remember { mutableStateOf("") }
    var away by remember { mutableStateOf("") }
    var selection by remember { mutableStateOf("") }
    var score by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("ROOM ADMIN", style = MaterialTheme.typography.headlineMedium)
        TextButton(onClick = onBack) { Text("Kembali") }
        OutlinedTextField(home, { home = it }, label = { Text("Tim tuan rumah") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(away, { away = it }, label = { Text("Tim tamu") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(selection, { selection = it }, label = { Text("Pilihan prediksi") }, modifier = Modifier.fillMaxWidth())
        Text("Kategori")
        listOf("Gratis", "Premium", "Premium HDC", "Premium Over Under").forEach {
            FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) })
        }
        Button(onClick = { onCreate(category, home, away, selection); home = ""; away = ""; selection = "" }) { Text("Simpan prediksi") }
        HorizontalDivider()
        Text("Pemberian Koin / VIP Member", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(memberUid, { memberUid = it }, label = { Text("UID member dari Firebase") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(grantCoins, { grantCoins = it }, label = { Text("Jumlah koin") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(grantVipDays, { grantVipDays = it }, label = { Text("Tambahan VIP (hari)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val c = grantCoins.toIntOrNull() ?: 0
            val d = grantVipDays.toIntOrNull() ?: 0
            if (memberUid.isNotBlank() && c >= 0 && d >= 0) onGrant(memberUid.trim(), c, d)
        }) { Text("Berikan Koin / VIP") }
        HorizontalDivider()
        Text("Koreksi hasil")
        LazyColumn {
            items(picks) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(8.dp)) {
                        Text("${p.home} vs ${p.away} (${p.category})")
                        OutlinedTextField(score, { score = it }, label = { Text("Skor akhir") })
                        Row {
                            Button(onClick = { onSettle(p.id, "WIN", score) }) { Text("WIN") }
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = { onSettle(p.id, "LOSE", score) }) { Text("LOSE") }
                        }
                    }
                }
            }
        }
        Text(message, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun openWhatsApp(message: String) {
    val context = LocalContext.current
    LaunchedEffect(message) {
        val uri = Uri.parse("https://wa.me/$WA?text=${Uri.encode(message)}")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    }
}
