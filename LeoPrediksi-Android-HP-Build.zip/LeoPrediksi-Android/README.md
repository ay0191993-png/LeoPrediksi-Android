# LeoPrediksi Android (starter project)

Project Android native Kotlin + Jetpack Compose + Firebase Authentication + Cloud Firestore.

## Yang sudah disiapkan
- Login dan pendaftaran email/password.
- Role member/admin dari dokumen `users/{uid}` (role admin wajib ditetapkan oleh backend/console, bukan dari aplikasi).
- Kategori: Gratis, Premium, Premium HDC, Premium Over Under.
- Paket koin: Rp10.000/10, Rp15.000/17, Rp20.000/25, Rp30.000/40.
- VIP: Rp5.000/3 hari, Rp10.000/6 hari, Rp15.000/11 hari, Rp20.000/15 hari.
- Konfirmasi pembelian melalui WhatsApp 085129371159.
- Input prediksi dan koreksi skor WIN/LOSE untuk admin.
- Firestore Rules dan Cloud Functions contoh untuk operasi sensitif.

## Penting
Ini adalah **source project**, bukan APK yang sudah ditandatangani atau aplikasi yang sudah online.
Untuk menjalankan:
1. Buat project Firebase di https://console.firebase.google.com.
2. Tambahkan aplikasi Android dengan package `id.leoprediksi.app`.
3. Unduh `google-services.json`, letakkan di `app/google-services.json`.
4. Aktifkan Authentication > Email/Password dan buat database Firestore.
5. Deploy `firestore.rules` dan folder `functions` (lihat `firebase.json`).
6. Jadikan akun admin dengan mengubah `users/{uid}.role` menjadi `admin` dari Firebase Console. Jangan sediakan fitur promosi admin di aplikasi.
7. Buka project ini di Android Studio, sinkronkan Gradle, lalu jalankan di perangkat.

## Keamanan produksi yang masih perlu diselesaikan
- Atur Firebase App Check dan batasi API key ke aplikasi Android.
- Tambahkan verifikasi pembayaran manual sebelum admin memberi koin/VIP.
- Cloud Functions contoh memakai Firebase Auth dan role Firestore; review dan uji sebelum produksi.
- Ganti password admin awal melalui alur akun yang aman. Jangan hardcode `aditya13` di APK.
- Gunakan HTTPS, backup Firestore, dan audit log.
